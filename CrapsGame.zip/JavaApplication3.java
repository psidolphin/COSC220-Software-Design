/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication3;
import java.util.Random;
/**
 *
 * @author Jared Ren
 */
public class JavaApplication3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Random firstRand = new Random();
        boolean done = false;
        while(done != true){
            int a = firstRand.nextInt(6);
            int b = firstRand.nextInt(6);
            System.out.print(a+1+"\n");
            System.out.print(b+1+"\n");
            if(a + b == 7 || a + b == 11){
                done = true;
                
            }
        }
        System.out.print("program is done");
    }    
}
