
package com.mycompany.crapsgame;

/**
 *
 * @author Jared Ren
 */
public interface Rollable {
   public int roll();
}
