
package com.mycompany.crapsgame;

      /*DiceSet myDice = new DiceSet();
      int a = myDice.rollDie();
      System.out.print("dice roll result\t"+a);\*
/**
 *
 * @author Jared Ren
 */
public class CrapsMain {
    public static void main(String[] args) {
      CrapsGUI myGUI = new CrapsGUI();
      myGUI.setTitle("The wonderful world of Craps");
      myGUI.setDefaultCloseOperation(myGUI.EXIT_ON_CLOSE);
      myGUI.setVisible(true);
    }
    
}
