
package com.mycompany.crapsgame;
import java.awt.*;
import javax.swing.*;
/**
 *
 * @author Jared Ren
 */
public class CrapsGUI extends JFrame {
    private JPanel namesbox;
    private JPanel dicebox;
    private JPanel playermenu;
    private JTextArea messagebox;

    
    public CrapsGUI(){
        
        //set dimensions for GUI
        Toolkit kit = Toolkit.getDefaultToolkit();
        Dimension screenSize = kit.getScreenSize();
        int screenHeight = screenSize.height;
        int screenWidth = screenSize.width;
        setSize(screenWidth / 2, screenHeight / 2);
        setLocationByPlatform(true);
        

        //initialize the fields
        namesbox = new JPanel();
        dicebox = new JPanel();
        playermenu = new JPanel();
        messagebox = new JTextArea(5,5);
        namesbox.setName("Names");
        dicebox.setName("dice area");
        messagebox.setName("message area");
        playermenu.setName("player menu");
   
        //names box layout
        setLayout(new BorderLayout());
        add(namesbox, BorderLayout.WEST);
        BoxLayout box1 = new BoxLayout(namesbox, BoxLayout.Y_AXIS);
        namesbox.setLayout(box1);
        namesbox.add(new JLabel("Name"));
        namesbox.add(new JLabel("Name"));
        namesbox.add(new JLabel("Name"));
        namesbox.add(new JLabel("Name"));
        
        
        
        
        //adds messagebox
        add(messagebox, BorderLayout.SOUTH);
        
        //add playermenu
        add(dicebox, BorderLayout.CENTER);
        BoxLayout box = new BoxLayout(dicebox, BoxLayout.Y_AXIS);
        dicebox.setLayout(box);
        dicebox.add(new JLabel("Round #"));
        dicebox.add(new JLabel("Current Player"));
        dicebox.add(new JLabel("Bet: $"));
        dicebox.add(new JLabel("First Roll"));
        dicebox.add(new JLabel("Current Roll"));
        dicebox.add(new JLabel("Die1"));
        dicebox.add(new JLabel("Die2"));
        dicebox.add(new JLabel("Total"));
        dicebox.add(new JButton("Roll"));
    
        
        
        
        
       
        add(playermenu, BorderLayout.EAST);
        BoxLayout box2 = new BoxLayout(playermenu, BoxLayout.Y_AXIS);
        playermenu.setLayout(box2);
        playermenu.add(new JButton("Add Player"));
        playermenu.add(new JTextField("name"));
        playermenu.add(new JButton("Done Adding"));
        playermenu.add(new JButton("Play next round"));
        playermenu.add(new JButton("Next Player Bet"));
        playermenu.add(new JTextField());
        playermenu.add(new JButton("Determine winner"));
        
    }

}
