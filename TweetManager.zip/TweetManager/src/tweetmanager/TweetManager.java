
package tweetmanager;
import java.util.Scanner;
import java.util.ArrayList;
/**
 *
 * @author Jared Ren
 */
public class TweetManager {
    static ArrayList<Tweet> tweetlist = new ArrayList<>(100);
    static Scanner menuselect = new Scanner(System.in);
    static Scanner addtweetmenu = new Scanner(System.in); 
    static Scanner srctweetmenu = new Scanner(System.in);
    
    
    
    
    public static void menu(){
       System.out.print("Tweet Manager\n");
       System.out.print("Choose Option\n");
       System.out.print(1);
       System.out.print("\tAdd a tweet to the manager\n");
       System.out.print(2);
       System.out.print("\tRead a tweet\n");
       System.out.print(3);
       System.out.print("\tUser tweet summary\n");
       System.out.print(4);
       System.out.print("\tBiggest tweeter\n");
    }
    public static void addtweet(){
        System.out.print("Username\t");
        String UserID = addtweetmenu.nextLine();
        System.out.print("Tweet Topic\t");
        String TweetTopic = addtweetmenu.nextLine();
        System.out.print("Tweet Text\t");
        String TweetText = addtweetmenu.nextLine();
        System.out.print("Tweet Date\t");
        String TweetDate = addtweetmenu.nextLine();
        Tweet bird = new Tweet(UserID, TweetTopic, TweetText, TweetDate);
        tweetlist.add(bird);
    }
    public static void readtweet(){
        ArrayList<Tweet> templist = new ArrayList<>(100);
        System.out.print("\nUsername to search for\t");
        String searchname = srctweetmenu.nextLine();
        for(Tweet item : tweetlist){
            if(searchname.equals(item.getUserId())){
                templist.add(item);
                System.out.print("\n"+templist.indexOf(item));
                System.out.print("\t"+item.getTweettopic());
            }
            else{
                System.out.print("user not found!");
            }     
        }
        System.out.print("enter tweet number to be read");
        int subjectnum = srctweetmenu.nextInt();
        for(Tweet i: templist){
            if(subjectnum == templist.indexOf(i)){
                System.out.print(i.getTweettext());
                i.Increment();
            }
            else{
                System.out.print("error");
            }
        }
        
    }
        
    
    public static void TweetSummary(){
        System.out.print("\nUsername to search for\t");
        String searchname = srctweetmenu.nextLine();
        tweetlist.forEach((item) -> {
            if (searchname.equals(item.getUserId())) {
                System.out.print("\n"+item.getTweettopic()+"\t");
                System.out.print(item.getNumReads());
            } else {
                System.out.print("user not found!");
            }
        });  
    }
    public static void biggestTweeter(){
        int numtweets = 0;
        ArrayList<String> nameslist = new ArrayList<>(tweetlist.size());
        for(Tweet pointer: tweetlist){
            nameslist.add(pointer.getUserId());  
        }
        nameslist.forEach((name) ->{
            int nextindex = name.indexOf(name)+1;
            if(name.matches(nameslist.get(nextindex))){
                numtweets++;
            }
            System.out.print(name);
            System.out.print(numtweets);
        }
        
        
    }
    public static void main(String[] args) {
      boolean done = false;
      while(done != true){
       menu();
       int i = menuselect.nextInt();
       switch (i){
           case 1:
               addtweet();
               break;
           case 2:
               readtweet();
               break;
           case 3:
               TweetSummary();
               break;
           case 4:
               biggestTweeter();
               break;
           default:
               System.out.print("invalid selection");
       }
       
    }    
}
}
