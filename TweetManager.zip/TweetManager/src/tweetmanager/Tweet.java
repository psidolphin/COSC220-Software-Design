
package tweetmanager;
public class Tweet {
    private String Tweettext;
    private String Tweettopic;
    private String UserId;
    private String Date;
    private int NumReads;
    
//Default Constructor
   public Tweet(){    
   }
    
//Constructor
   public Tweet(String userID, String tweettopic, String tweettext, String date){
       NumReads = 0;
       UserId = userID;
       Tweettopic = tweettopic;
       Tweettext = tweettext;
       Date = date;      
   }
   
   

//increment method   
public void Increment(){
    NumReads++;
}
   
   
//Accessor Methods
   public String getTweettext(){
       return Tweettext;
   }
   public String getTweettopic(){
       return Tweettopic;
   }   
   public String getUserId(){
       return UserId;
   }
   public int getNumReads(){
       return NumReads;
   }
   public String getDate(){
       return Date;
   }
//mutator methods
   public void setTweettext(String tweettext){
       Tweettext = tweettext; 
   }

   public void setTweettopic(String tweettopic){
       Tweettopic = tweettopic;
   }
   public void setUserId(String userid){
       UserId = userid;
   }

}



