
package com.mycompany.crapsgame;

/**
 *
 * @author Jared Ren
 */
public class Player {
    //fields
    private int bank;
    private int betAmount;
    private String name;
    
    //constructor
    Player(int bank, String name, int betAmount){
        bank = 0;
        betAmount = 0;
        name = "";
    }
    
    
    
    //accessors
    public String getName(){
        return name;
    }
    public int getBank(){
        return bank;
    }
    public int getBet(){
        return betAmount;
    }
    
    //mutators
    public void setName(String newName){
        name = newName;
    }
    
    public void setBank(int amt){
        bank = amt;
    }
    
    public void setBet(int amt){
        betAmount = amt;
    }
    
    //normal methods
    
    public void addToBank(int amt){
        bank += amt;
    }
    
    public void takeFromBank(int amt){
        bank -= amt;
    }
    
    
    
    
    
    
    
    
    
}
