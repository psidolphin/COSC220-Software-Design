
package com.mycompany.crapsgame;
import java.util.LinkedList;
/**
 *
 * @author Jared Ren
 */
public class PlayerList {
    private LinkedList<Player> players  = new LinkedList<>();
    private int numPlayers;
    
    
    public Player getPlayer (int i){
       return players.get(i);
    }
    
    public Player getPlayer(String name){
        for(Player i : players){
            if(name.equals(i.getName())){
                return i;
            }else{
        return null;
    }
        }
        return null;
    }
    public void addNewPlayer(Player newPlayer){
        players.add(newPlayer);
    }
    
    
    
    
    
    
}
