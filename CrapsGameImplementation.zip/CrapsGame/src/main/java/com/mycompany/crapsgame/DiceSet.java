
package com.mycompany.crapsgame;

/**
 *
 * @author Jared Ren
 */
public class DiceSet {
   private Die die1 = new Die();
   private Die die2 = new Die();

   public int rollDie(){
       int a = die1.roll() + die2.roll();
       return a;
   }
   public int getDie1(){
       return die1.getValue();
   }
   public int getDie2(){
       return die2.getValue();
   }






}
