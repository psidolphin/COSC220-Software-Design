
package com.mycompany.crapsgame;
import java.util.Random;

/**
 *
 * @author Jared Ren
 */
public class Die implements Rollable {
    private int value;

    public int getValue(){
        return value;
    
    }

    public int roll(){
        Random rando = new Random();
        int a = rando.nextInt(6) + 1;
        return a;
    }







}

