/*
 * A  Java Twitter Clone
 * By  Jared Ren and Tyler Steward  * 
 */
package jtc;

/**
 *
 * @author Jared Ren
 */
public class PrivateTweet {
    
}
