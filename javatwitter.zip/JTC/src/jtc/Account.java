/*
 * A  Java Twitter Clone
 * By  Jared Ren and Tyler Steward  * 
 */
package jtc;

/**
 *
 * @author Jared Ren
 */
public class Account {
    private String username;
    private String password;

    public Account(String username, String password) {
        this.username = username;
        this.password = password;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}
